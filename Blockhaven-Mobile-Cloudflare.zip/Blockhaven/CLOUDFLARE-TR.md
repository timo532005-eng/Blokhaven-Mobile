# Blockhaven — Cloudflare dağıtım rehberi (Türkçe)

## Önemli
Cloudflare Dashboard'daki **dosya yükleme (Direct Upload)** ekranı bu projeyi kabul etmeyebilir; çünkü proje `wrangler.toml`, Worker ve Durable Objects kullanıyor. Bu hata, oyunun kodunun bozuk olduğunu göstermez. Bu projeyi o ekrana tekrar ZIP olarak yüklemek çözüm değildir.

Bu proje için Node.js ve terminal çalıştırabilen bir geliştirme ortamı gerekir. Sadece Android telefondaki normal tarayıcı ve Cloudflare dosya yükleme ekranı yeterli değildir.

## Komutla dağıtım
1. `Blockhaven` klasörünü, terminali olan Node.js destekli bir bulut geliştirme ortamına yükleyip aç.
2. Terminalin bu klasörde olduğundan emin ol. Klasörde `package.json` ve `wrangler.toml` dosyaları görünmeli.
3. Şu komutları sırayla çalıştır:

```sh
npm install
npm run login
npm run deploy
```

4. `npm run login` Cloudflare hesabına giriş işlemini başlatır. Ekrandaki adımları tamamla.
5. `npm run deploy` bittiğinde Wrangler'ın verdiği `https://...workers.dev` adresini aç.

İstersen `sh deploy.sh` komutuyla da yükleme, giriş ve dağıtım adımlarını başlatabilirsin; giriş sırasında senden onay istenebilir.

## Yerel test komutları

```sh
npm test
npm run check
```

Bu komutlar otomatik yardımcı testlerini ve JavaScript sözdizimini kontrol eder; gerçek telefonda WebGL, dokunmatik kontroller ve çok oyunculu bağlantı ayrıca test edilmelidir.

## Sorun giderme
- `npm: command not found` veya `node: command not found`: Node.js/terminal olmayan bir ortamdasın.
- `wrangler login` giriş hatası: tarayıcıda açılan Cloudflare yetkilendirme adımlarını tamamla ve tekrar dene.
- `wrangler deploy` yapılandırma veya Durable Objects hatası verirse, hatanın tamamını kopyala; ona göre `wrangler.toml` dosyasını düzeltmek gerekir.
- Bu paket komutları hazırlar ama senin adına Cloudflare hesabına giriş yapamaz veya oyunu otomatik olarak yayımlayamaz.
