#!/usr/bin/env sh
# Blockhaven Cloudflare deployment helper.
# Run from the Blockhaven project folder in a Node.js-enabled terminal.
set -eu

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is not installed in this environment. Open a Node.js-enabled cloud terminal first." >&2
  exit 1
fi

if ! command -v npm >/dev/null 2>&1; then
  echo "npm is not available in this environment." >&2
  exit 1
fi

npm install
printf '\nNext, sign in to Cloudflare in the browser that Wrangler opens.\n'
npm run login
printf '\nDeploying Blockhaven to Cloudflare...\n'
npm run deploy
