const ROOM_RE = /^[A-Z0-9]{4,8}$/;
const BLOCK_TYPES = new Set(['grass','dirt','stone','wood','leaves','sand']);
const MAX_PLAYERS = 16;

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === '/ws') {
      if (request.headers.get('Upgrade') !== 'websocket') return new Response('WebSocket upgrade required', { status: 426 });
      const room = (url.searchParams.get('room') || '').toUpperCase();
      if (!ROOM_RE.test(room)) return new Response('Invalid room code', { status: 400 });
      const id = env.GAME_ROOMS.idFromName(room);
      return env.GAME_ROOMS.get(id).fetch(request);
    }
    return env.ASSETS.fetch(request);
  }
};

export class GameRoom {
  constructor(ctx, env) {
    this.ctx = ctx;
    this.env = env;
    this.players = new Map();
    this.blocks = new Map();
    this.mode = 'creative';
    this.ready = this.load();
  }
  async load() {
    const storedBlocks = await this.ctx.storage.get('blocks');
    if (Array.isArray(storedBlocks)) this.blocks = new Map(storedBlocks.map(b => [`${b.x},${b.y},${b.z}`, b]));
    // Durable Objects may hibernate while sockets remain connected; rebuild transient player state from attachments.
    for (const socket of this.ctx.getWebSockets()) { const a = socket.deserializeAttachment() || {}; if (a.id) this.players.set(a.id, { id:a.id, name:cleanName(a.name || 'Gezgin'), x:Number.isFinite(a.x)?a.x:0.5, y:Number.isFinite(a.y)?a.y:7, z:Number.isFinite(a.z)?a.z:0.5, yaw:Number.isFinite(a.yaw)?a.yaw:0 }); }
    this.mode = (await this.ctx.storage.get('mode')) || 'creative';
  }
  async fetch(request) {
    await this.ready;
    const pair = new WebSocketPair();
    const client = pair[0];
    const server = pair[1];
    this.ctx.acceptWebSocket(server);
    const url = new URL(request.url);
    const name = cleanName(url.searchParams.get('name') || 'Gezgin');
    const id = crypto.randomUUID();
    server.serializeAttachment({ id, name, x:0.5, y:7, z:0.5, yaw:0 });
    if (this.players.size >= MAX_PLAYERS) { server.send(JSON.stringify({ t: 'error', message: 'Oda dolu (en fazla 16 oyuncu).' })); server.close(1008, 'Room full'); return new Response(null, { status: 101, webSocket: client }); }
    this.players.set(id, { id, name, x: 0.5, y: 7, z: 0.5, yaw: 0 });
    server.send(JSON.stringify({ t: 'welcome', id, mode: this.mode, players: [...this.players.values()].filter(p => p.id !== id), blocks: [...this.blocks.values()] }));
    this.broadcast({ t: 'player', player: this.players.get(id) }, server);
    return new Response(null, { status: 101, webSocket: client });
  }
  webSocketMessage(ws, raw) {
    const att = ws.deserializeAttachment() || {};
    let m; try { m = JSON.parse(raw); } catch { return; }
    if (!m || typeof m.t !== 'string') return;
    if (m.t === 'join') {
      const p = this.players.get(att.id); if (p) { p.name = cleanName(m.name || p.name); this.broadcast({t:'players',list:[...this.players.values()]}); }
      return;
    }
    if (m.t === 'move') {
      const p = this.players.get(att.id); if (!p) return;
      const x = finiteClamp(m.x, -10000, 10000), y = finiteClamp(m.y, -100, 1000), z = finiteClamp(m.z, -10000, 10000), yaw = finiteClamp(m.yaw, -100, 100);
      if ([x,y,z,yaw].some(v => v === null)) return;
      p.x=x; p.y=y; p.z=z; p.yaw=yaw; p.name=cleanName(m.name||p.name); ws.serializeAttachment({id:att.id,name:p.name,x,y,z,yaw});
      this.broadcast({ t:'player', player:p }, ws); return;
    }
    if (m.t === 'block') {
      if (!Number.isInteger(m.x)||!Number.isInteger(m.y)||!Number.isInteger(m.z)||Math.abs(m.x)>10000||Math.abs(m.z)>10000||m.y<0||m.y>128) return;
      const key=`${m.x},${m.y},${m.z}`;
      if (m.op === 'del') this.blocks.set(key,{t:'block',op:'del',x:m.x,y:m.y,z:m.z});
      else if (m.op === 'set' && BLOCK_TYPES.has(m.type)) this.blocks.set(key,{t:'block',op:'set',x:m.x,y:m.y,z:m.z,type:m.type});
      else return;
      this.broadcast({t:'block',op:m.op,x:m.x,y:m.y,z:m.z,type:m.type});
      this.ctx.storage.put('blocks',[...this.blocks.values()]).catch(()=>{}); return;
    }
    if (m.t === 'mode' && (m.mode === 'creative' || m.mode === 'survival')) {
      this.mode=m.mode; this.ctx.storage.put('mode',this.mode).catch(()=>{}); this.broadcast({t:'mode',mode:this.mode});
    }
  }
  webSocketClose(ws) { this.removePlayer(ws); }
  webSocketError(ws) { this.removePlayer(ws); }
  removePlayer(ws) {
    const att=ws.deserializeAttachment()||{}; if (!att.id) return;
    this.players.delete(att.id); this.broadcast({t:'left',id:att.id}); this.broadcast({t:'players',list:[...this.players.values()]});
  }
  broadcast(message, except=null) {
    const data=JSON.stringify(message);
    for (const ws of this.ctx.getWebSockets()) { if (ws===except) continue; try { ws.send(data); } catch {} }
  }
}
function cleanName(s){return String(s).replace(/[<>\u0000-\u001f]/g,'').trim().slice(0,16)||'Gezgin';}
function finiteClamp(v,min,max){return typeof v==='number'&&Number.isFinite(v)&&v>=min&&v<=max?v:null;}
