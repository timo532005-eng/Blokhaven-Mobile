import * as THREE from 'three';

const $ = (id) => document.getElementById(id);
const ui = {
  welcome: $('welcome'), hud: $('hud'), loading: $('loading'), name: $('playerName'), room: $('roomCode'),
  play: $('playButton'), newRoom: $('randomRoomButton'), roomLabel: $('roomLabel'), connectionDot: $('connectionDot'),
  connectionText: $('connectionText'), modeLabel: $('modeLabel'), playersLabel: $('playersLabel'), modeButton: $('modeButton'),
  copyRoom: $('copyRoomButton'), leave: $('leaveButton'), toast: $('toast'), hotbar: $('hotbar'), mobile: $('mobileControls'),
  joystick: $('joystick'), knob: $('joystickKnob'), jump: $('jumpButton'), break: $('breakButton'), place: $('placeButton'), menu: $('menuButton'), help: $('helpCard')
};
const BLOCKS = {
  grass: { color: 0x67b84f, name: 'Çimen' }, dirt: { color: 0x8c5b39, name: 'Toprak' },
  stone: { color: 0x89959c, name: 'Taş' }, wood: { color: 0x9a673b, name: 'Odun' },
  leaves: { color: 0x38864b, name: 'Yaprak' }, sand: { color: 0xd9c17c, name: 'Kum' }
};
const isTouch = matchMedia('(pointer: coarse)').matches || navigator.maxTouchPoints > 0;
let scene, camera, renderer, clock, ws, roomCode = '', playerId = '', playerName = 'Gezgin', mode = 'creative', selectedBlock = 'grass';
let worldGroup, remoteGroup, blockMeshes = new Map(), remotePlayers = new Map(), blockData = new Map(), localEdits = new Map(), keys = {}, yaw = 0, pitch = 0;
let velocityY = 0, onGround = false, started = false, moveVec = {x:0,z:0}, joystickPointer = null, joystickOrigin = null, lookPointer = null, lastLook = null, toastTimer, saveKey = '';
const WORLD_SIZE = 56, REACH = 7;
const materialCache = {};
const cameraDir = new THREE.Vector3();

function hash2(x,z,seed){ let n = Math.imul(x,374761393)+Math.imul(z,668265263)+Math.imul(seed,1442695041); n=Math.imul(n^(n>>>13),1274126177); return ((n^(n>>>16))>>>0)/4294967295; }
function terrainHeight(x,z,seed){ const broad=Math.sin((x+seed%17)*.14)*1.7+Math.cos((z-seed%13)*.13)*1.4; const hills=(hash2(Math.floor(x/5),Math.floor(z/5),seed)-.5)*2.3; return Math.max(1,Math.floor(3+broad+hills)); }
function key3(x,y,z){return `${x},${y},${z}`}
function parseKey(k){return k.split(',').map(Number)}
function getMaterial(type){ if(!materialCache[type]) materialCache[type]=new THREE.MeshLambertMaterial({color:BLOCKS[type]?.color??0xffffff,flatShading:true}); return materialCache[type]; }
function showToast(text){ui.toast.textContent=text;ui.toast.classList.remove('hidden');clearTimeout(toastTimer);toastTimer=setTimeout(()=>ui.toast.classList.add('hidden'),2300)}
function setConnection(ok,text){ui.connectionDot.classList.toggle('online',ok);ui.connectionText.textContent=text}
function makeBlock(x,y,z,type,send=false){
  const k=key3(x,y,z); if(blockData.has(k)) removeBlock(x,y,z,false);
  const mesh=new THREE.Mesh(new THREE.BoxGeometry(1,1,1),getMaterial(type)); mesh.position.set(x+.5,y+.5,z+.5); mesh.userData={x,y,z,type}; mesh.castShadow=true;mesh.receiveShadow=true;worldGroup.add(mesh);blockMeshes.set(k,mesh);blockData.set(k,type);
  if(send && ws?.readyState===WebSocket.OPEN) ws.send(JSON.stringify({t:'block',op:'set',x,y,z,type}));
}
function removeBlock(x,y,z,send=true){const k=key3(x,y,z),mesh=blockMeshes.get(k);if(mesh){worldGroup.remove(mesh);mesh.geometry.dispose();blockMeshes.delete(k);blockData.delete(k);if(send&&ws?.readyState===WebSocket.OPEN)ws.send(JSON.stringify({t:'block',op:'del',x,y,z}));return true}return false}
function createTree(x,z,base,seed){const h=3+Math.floor(hash2(x,z,seed+4)*2);for(let y=0;y<h;y++)makeBlock(x,base+y,z,'wood');for(let dx=-2;dx<=2;dx++)for(let dz=-2;dz<=2;dz++)for(let dy=h-2;dy<=h+1;dy++){if(Math.abs(dx)+Math.abs(dz)+(dy===h+1?1:0)<=4 && !(dx===0&&dz===0&&dy<base+h))makeBlock(x,base+dy,z,'leaves');}}
function generateWorld(){
  worldGroup=new THREE.Group();scene.add(worldGroup);remoteGroup=new THREE.Group();scene.add(remoteGroup);const seed=[...roomCode].reduce((a,c)=>a+c.charCodeAt(0),0)||1;
  const half=WORLD_SIZE/2;for(let x=-half;x<half;x++)for(let z=-half;z<half;z++){const h=terrainHeight(x,z,seed);for(let y=0;y<h;y++){let type=y===h-1?'grass':y>h-4?'dirt':'stone';makeBlock(x,y,z,type,false)}if(hash2(x,z,seed)>.987 && Math.abs(x)>3&&Math.abs(z)>3)createTree(x,z,h,seed)}
  // Restore saved local blocks and then authoritative room edits.
  try{const saved=JSON.parse(localStorage.getItem(saveKey)||'{}');for(const [k,v] of Object.entries(saved)){const [x,y,z]=parseKey(k);localEdits.set(k,v);if(v==='del')removeBlock(x,y,z,false);else if(BLOCKS[v])makeBlock(x,y,z,v,false)}}catch{}
}
function initThree(){
  scene=new THREE.Scene();scene.background=new THREE.Color(0x8cc9e8);scene.fog=new THREE.Fog(0x8cc9e8,30,78);
  camera=new THREE.PerspectiveCamera(76,innerWidth/innerHeight,.1,120);camera.position.set(0,8,8);
  renderer=new THREE.WebGLRenderer({antialias:false,powerPreference:'high-performance'});renderer.setPixelRatio(Math.min(devicePixelRatio,isTouch?1.25:1.7));renderer.setSize(innerWidth,innerHeight);renderer.shadowMap.enabled=false;renderer.outputColorSpace=THREE.SRGBColorSpace;document.getElementById('game').appendChild(renderer.domElement);
  scene.add(new THREE.HemisphereLight(0xdaf5ff,0x4d6041,2.1));const sun=new THREE.DirectionalLight(0xfff2d5,2.2);sun.position.set(-20,35,15);scene.add(sun);
  clock=new THREE.Clock();generateWorld();window.addEventListener('resize',resize);renderer.domElement.addEventListener('contextmenu',e=>e.preventDefault());renderer.domElement.addEventListener('pointerdown',onCanvasDown);document.addEventListener('pointerlockchange',()=>{});requestAnimationFrame(animate);
}
function resize(){if(!camera||!renderer)return;camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)}
function animate(){requestAnimationFrame(animate);if(!renderer)return;const dt=Math.min(clock.getDelta(),.05);if(started){updateMovement(dt);updateCamera();}renderer.render(scene,camera)}
function updateMovement(dt){
  let forward=(keys.KeyW?1:0)-(keys.KeyS?1:0)+moveVec.z;let side=(keys.KeyD?1:0)-(keys.KeyA?1:0)+moveVec.x;const len=Math.hypot(forward,side);if(len>1){forward/=len;side/=len}
  const speed=mode==='creative'?7:4.8;const dx=(Math.sin(yaw)*forward+Math.cos(yaw)*side)*speed*dt;const dz=(-Math.cos(yaw)*forward+Math.sin(yaw)*side)*speed*dt;
  const nx=camera.position.x+dx,nz=camera.position.z+dz;const floor=groundAt(nx,nz)+1.62;if(mode==='creative'){camera.position.x=nx;camera.position.z=nz;if(keys.Space||keys.ArrowUp)camera.position.y+=speed*dt;if(keys.ShiftLeft||keys.ArrowDown)camera.position.y-=speed*dt;camera.position.y=Math.max(2,camera.position.y)}else{if(!collides(nx,camera.position.y,nz)) {camera.position.x=nx;camera.position.z=nz}velocityY-=19*dt;camera.position.y+=velocityY*dt;if(camera.position.y<floor){camera.position.y=floor;velocityY=0;onGround=true}else onGround=false}
  if(ws?.readyState===WebSocket.OPEN && Math.random()<.16)ws.send(JSON.stringify({t:'move',x:camera.position.x,y:camera.position.y,z:camera.position.z,yaw,name:playerName}));
}
function groundAt(x,z){let best=0;for(const [k] of blockData){const [bx,by,bz]=parseKey(k);if(bx===Math.floor(x)&&bz===Math.floor(z)&&by+1>best)best=by+1}return best}
function collides(x,y,z){const bx=Math.floor(x),bz=Math.floor(z);for(let yy=Math.floor(y-1.6);yy<=Math.floor(y-.1);yy++)if(blockData.has(key3(bx,yy,bz)))return true;return false}
function updateCamera(){camera.rotation.order='YXZ';camera.rotation.y=yaw;camera.rotation.x=pitch}
function raycastBlock(){camera.updateMatrixWorld();camera.getWorldDirection(cameraDir);const ray=new THREE.Raycaster(camera.position,cameraDir,0,REACH);const hits=ray.intersectObjects(worldGroup.children,false);return hits[0]||null}
function interact(place){if(!started)return;const hit=raycastBlock();if(!hit){showToast('Blok menzilde değil');return}const d=hit.object.userData;if(!place){if(mode==='survival'&&d.y<=0){showToast('Bu blok kırılamaz');return}removeBlock(d.x,d.y,d.z,true);localEdits.set(key3(d.x,d.y,d.z),'del')}else{const normal=hit.face.normal.clone().transformDirection(hit.object.matrixWorld);const x=d.x+Math.round(normal.x),y=d.y+Math.round(normal.y),z=d.z+Math.round(normal.z);if(y<0||y>50)return;if(Math.abs(x-camera.position.x)<.8&&Math.abs(z-camera.position.z)<.8&&y<camera.position.y&&y+1>camera.position.y-1.7){showToast('Kendinin içine blok koyamazsın');return}if(mode==='survival'){const count=Number(localStorage.getItem('bh_blocks_'+roomCode)||'30');if(count<=0){showToast('Blok kalmadı');return}localStorage.setItem('bh_blocks_'+roomCode,String(count-1))}makeBlock(x,y,z,selectedBlock,true);localEdits.set(key3(x,y,z),selectedBlock)}saveLocalEdits()}
function saveLocalEdits(){const out=Object.fromEntries(localEdits);try{localStorage.setItem(saveKey,JSON.stringify(out))}catch{showToast('Yerel kayıt alanı dolu olabilir')}}
function connect(){const protocol=location.protocol==='https:'?'wss:':'ws:';const url=`${protocol}//${location.host}/ws?room=${encodeURIComponent(roomCode)}&name=${encodeURIComponent(playerName)}`;ws=new WebSocket(url);setConnection(false,'Bağlanıyor…');ws.addEventListener('open',()=>{setConnection(true,'Bağlandı');ws.send(JSON.stringify({t:'join',name:playerName,mode}));showToast('Oda bağlantısı kuruldu')});ws.addEventListener('message',e=>{let m;try{m=JSON.parse(e.data)}catch{return}handleMessage(m)});ws.addEventListener('close',()=>{setConnection(false,'Bağlantı kesildi');if(started)showToast('Sunucu bağlantısı kesildi')});ws.addEventListener('error',()=>{setConnection(false,'Bağlantı hatası');showToast('Sunucuya ulaşılamadı. Yayındaki sunucu adresini kontrol et.')})}
function handleMessage(m){if(m.t==='welcome'){playerId=m.id||'';if(m.blocks)for(const b of m.blocks)applyRemoteBlock(b);if(m.players)for(const p of m.players)addOrUpdatePlayer(p);if(m.mode){mode=m.mode;updateModeUI()}return}if(m.t==='players'){for(const p of m.list||[])addOrUpdatePlayer(p);ui.playersLabel.textContent=`Oyuncu: ${Math.max(1,m.list?.length||1)}`;return}if(m.t==='player'){addOrUpdatePlayer(m.player);return}if(m.t==='left'){removeRemotePlayer(m.id);return}if(m.t==='block'){applyRemoteBlock(m);return}if(m.t==='mode'){mode=m.mode;updateModeUI();return}if(m.t==='error')showToast(m.message||'Sunucu hatası')}
function applyRemoteBlock(b){if(!Number.isInteger(b.x)||!Number.isInteger(b.y)||!Number.isInteger(b.z))return;const k=key3(b.x,b.y,b.z);if(b.op==='del'){removeBlock(b.x,b.y,b.z,false);localEdits.set(k,'del')}else if(BLOCKS[b.type]){makeBlock(b.x,b.y,b.z,b.type,false);localEdits.set(k,b.type)}}
function addOrUpdatePlayer(p){if(!p||!p.id||p.id===playerId)return;let obj=remotePlayers.get(p.id);if(!obj){obj=new THREE.Group();const body=new THREE.Mesh(new THREE.BoxGeometry(.65,1.1,.4),new THREE.MeshLambertMaterial({color:new THREE.Color().setHSL(Math.random(),.55,.52)}));body.position.y=-.55;obj.add(body);const head=new THREE.Mesh(new THREE.BoxGeometry(.48,.48,.48),new THREE.MeshLambertMaterial({color:0xe6bd92}));head.position.y=.25;obj.add(head);remoteGroup.add(obj);remotePlayers.set(p.id,obj)}if(Number.isFinite(p.x))obj.position.set(p.x,p.y-1.1,p.z);if(Number.isFinite(p.yaw))obj.rotation.y=p.yaw}
function removeRemotePlayer(id){const obj=remotePlayers.get(id);if(obj){remoteGroup.remove(obj);remotePlayers.delete(id)}ui.playersLabel.textContent=`Oyuncu: ${remotePlayers.size+1}`}
function updateModeUI(){ui.modeLabel.textContent=mode==='creative'?'YARATICI':'HAYATTA KALMA';document.querySelector('.mode-dot').style.background=mode==='creative'?'#b8f36b':'#f3c96b'}
function startGame(){localEdits=new Map();roomCode=(ui.room.value.trim().toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,8)||Math.random().toString(36).slice(2,8).toUpperCase());ui.room.value=roomCode;ui.roomLabel.textContent=roomCode;playerName=(ui.name.value.trim().slice(0,16)||'Gezgin');saveKey='blockhaven_edits_'+roomCode;started=true;ui.welcome.classList.add('hidden');ui.hud.classList.remove('hidden');ui.help.classList.toggle('hidden',isTouch);ui.mobile.classList.toggle('hidden',!isTouch);ui.loading.classList.remove('hidden');
  if(!scene)initThree();else{while(worldGroup?.children.length)worldGroup.remove(worldGroup.children[0]);for(const m of remotePlayers.values())remoteGroup.remove(m);remotePlayers.clear();blockMeshes.clear();blockData.clear();scene.remove(worldGroup);scene.remove(remoteGroup);generateWorld()}
  const spawnY=terrainHeight(0,0,[...roomCode].reduce((a,c)=>a+c.charCodeAt(0),0))+2;camera.position.set(.5,spawnY+1.6,.5);yaw=0;pitch=0;setTimeout(()=>ui.loading.classList.add('hidden'),400);if(ws)ws.close();connect();
  if(!isTouch){renderer.domElement.requestPointerLock?.().catch?.(()=>{});showToast('Ekrana tıkla ve fareyle bak')}
}
function onCanvasDown(e){if(!started)return;if(!isTouch&&document.pointerLockElement!==renderer.domElement&&e.button===0){renderer.domElement.requestPointerLock?.();return}if(isTouch){if(e.clientX<innerWidth*.42)return;lookPointer=e.pointerId;lastLook={x:e.clientX,y:e.clientY};renderer.domElement.setPointerCapture?.(e.pointerId);return}if(e.button===0)interact(false);if(e.button===2)interact(true)}
document.addEventListener('mousemove',e=>{if(started&&!isTouch&&document.pointerLockElement===renderer.domElement){yaw-=e.movementX*.0022;pitch-=e.movementY*.0022;pitch=Math.max(-1.5,Math.min(1.5,pitch))}});
document.addEventListener('pointermove',e=>{if(isTouch&&lookPointer===e.pointerId&&lastLook){yaw-=(e.clientX-lastLook.x)*.008;pitch-=(e.clientY-lastLook.y)*.008;pitch=Math.max(-1.35,Math.min(1.35,pitch));lastLook={x:e.clientX,y:e.clientY}}});
document.addEventListener('pointerup',e=>{if(lookPointer===e.pointerId){lookPointer=null;lastLook=null}if(joystickPointer===e.pointerId){joystickPointer=null;moveVec={x:0,z:0};ui.knob.style.transform='translate(0,0)'}});
document.addEventListener('keydown',e=>{keys[e.code]=true;if(['Space','ArrowUp','ArrowDown'].includes(e.code))e.preventDefault();if(e.code.startsWith('Digit')){const n=Number(e.code.slice(5));const slot=document.querySelector(`.slot[data-index="${n}"]`)||document.querySelectorAll('.slot')[n-1];if(slot)selectSlot(slot)}if(e.code==='KeyM'&&started)toggleMode()});document.addEventListener('keyup',e=>keys[e.code]=false);
function selectSlot(slot){document.querySelectorAll('.slot').forEach(s=>s.classList.remove('selected'));slot.classList.add('selected');selectedBlock=slot.dataset.block||'grass';showToast(BLOCKS[selectedBlock].name)}
function toggleMode(){mode=mode==='creative'?'survival':'creative';updateModeUI();if(ws?.readyState===WebSocket.OPEN)ws.send(JSON.stringify({t:'mode',mode}));showToast(mode==='creative'?'Yaratıcı mod':'Hayatta kalma modu')}
ui.hotbar.querySelectorAll('.slot').forEach(s=>s.addEventListener('click',()=>selectSlot(s)));ui.play.addEventListener('click',startGame);ui.newRoom.addEventListener('click',()=>{ui.room.value=Math.random().toString(36).slice(2,8).toUpperCase();showToast('Yeni oda kodu oluşturuldu')});ui.modeButton.addEventListener('click',toggleMode);ui.copyRoom.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(roomCode);showToast('Oda kodu kopyalandı')}catch{showToast('Oda kodun: '+roomCode)}});ui.leave.addEventListener('click',()=>{started=false;ws?.close();document.exitPointerLock?.();ui.hud.classList.add('hidden');ui.mobile.classList.add('hidden');ui.welcome.classList.remove('hidden');ui.loading.classList.add('hidden')});ui.menu.addEventListener('click',()=>ui.help.classList.toggle('hidden'));
ui.joystick.addEventListener('pointerdown',e=>{joystickPointer=e.pointerId;joystickOrigin={x:e.clientX,y:e.clientY};ui.joystick.setPointerCapture(e.pointerId);moveJoystick(e)});ui.joystick.addEventListener('pointermove',e=>{if(joystickPointer===e.pointerId)moveJoystick(e)});function moveJoystick(e){const dx=e.clientX-joystickOrigin.x,dy=e.clientY-joystickOrigin.y,len=Math.hypot(dx,dy),scale=len>34?34/len:1;const x=dx*scale,y=dy*scale;ui.knob.style.transform=`translate(${x}px,${y}px)`;moveVec={x:x/34,z:y/34}}
ui.jump.addEventListener('pointerdown',e=>{e.preventDefault();if(mode==='creative')keys.Space=true;else if(onGround){velocityY=7.5;onGround=false}});ui.jump.addEventListener('pointerup',()=>keys.Space=false);ui.break.addEventListener('pointerdown',e=>{e.preventDefault();interact(false)});ui.place.addEventListener('pointerdown',e=>{e.preventDefault();interact(true)});
// Local unit tests can import this deterministic helper without loading Three.js.
export { hash2, terrainHeight, key3, parseKey };
