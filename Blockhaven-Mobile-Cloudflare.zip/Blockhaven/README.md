# Blockhaven — 3D voxel multiplayer starter

Blockhaven is a small, original browser voxel sandbox starter. It uses Three.js in the browser and a Cloudflare Worker + Durable Objects WebSocket room server. It is a prototype, not a finished Minecraft-scale game.

## Mobile-first notes
- Designed to run in a mobile browser with on-screen joystick, drag-to-look, jump, break and place controls.
- Larger touch targets, safe-area spacing for notched screens, and separate narrow-screen / landscape layout rules.
- For best testing, open the deployed HTTPS link in Safari or Chrome on the phone. On iOS, WebGL and browser memory limits depend on the device and browser version.

## Current prototype features
- First-person camera and procedural small terrain area
- Grass, dirt, stone, wood and leaves blocks
- Block placement/removal and local browser persistence
- Creative/survival mode toggle (prototype rules)
- Room-code-based WebSocket rooms, remote player avatars and shared block edits
- Mobile-first joystick, drag-to-look controls, jump/break/place buttons and safe-area responsive layout
- Cloudflare deployment configuration

## Project files
- `public/index.html` — page and UI
- `public/src/style.css` — responsive UI
- `public/src/main.js` — Three.js game client
- `worker/index.js` — WebSocket gateway and Durable Object room server
- `wrangler.toml` — Cloudflare configuration
- `tests/helpers.test.mjs` — deterministic helper tests

## Run locally (requires a computer with Node.js)
1. Install Node.js LTS.
2. Open a terminal in this folder.
3. Run `npm install`.
4. Run `npx wrangler dev`.
5. Open the local URL shown by Wrangler, usually `http://localhost:8787`.
6. Open a second browser tab/device at the same local URL and enter the same room code to test multiplayer. For another physical device on the same Wi-Fi, use the LAN URL if your dev setup exposes one; otherwise deploy a test version.

The Three.js module is loaded from jsDelivr, so the browser needs an internet connection.

## Test and syntax-check
- `npm test`
- `npm run check`

These checks cover helper determinism and JavaScript syntax only. They do not prove that WebGL, Cloudflare deployment, mobile touch controls, or two-device multiplayer work. Test those manually before sharing the public link.

## Deploy (Cloudflare)
1. Create a Cloudflare account and install Node.js on a computer.
2. From this folder run `npm install`.
3. Authenticate Wrangler: `npx wrangler login`.
4. Deploy with `npx wrangler deploy`.
5. Wrangler will print the deployed URL. Open it on your phone and computer.
6. To update the game, edit files and run `npx wrangler deploy` again.

Cloudflare's free plan and Durable Objects limits can change. Check current plan details before inviting many players. Static hosting and real-time room coordination are separate components; this project uses Durable Objects for the latter.

## Important prototype limits
- The generated world is intentionally modest (56×56 columns) to avoid freezing phones. “Large procedural world” needs chunk streaming and meshing before it is suitable for a large map.
- The world seed is based on the room code. Different room codes generate different terrain.
- Block changes are saved in the room Durable Object. Initial terrain is generated client-side.
- Survival mode currently adds a simple block-count limit, but it does not yet have hunger, health, crafting, mobs or robust inventory persistence.
- Player movement is client-authoritative in this starter. Do not treat it as cheat-resistant or secure for a competitive game.
- Public room discovery, account login, moderation, anti-cheat, chunk loading, optimized merged geometry, advanced persistence, crafting, and polished avatar models are not implemented.
- Use your own original name, art, sounds and block textures. Do not copy Minecraft branding or assets.
