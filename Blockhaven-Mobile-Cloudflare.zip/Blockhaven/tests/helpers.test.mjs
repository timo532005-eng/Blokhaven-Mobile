import test from 'node:test';
import assert from 'node:assert/strict';
// Keep deterministic world helper logic mirrored here so tests run in plain Node without browser/Three.js.
function hash2(x,z,seed){let n=Math.imul(x,374761393)+Math.imul(z,668265263)+Math.imul(seed,1442695041);n=Math.imul(n^(n>>>13),1274126177);return ((n^(n>>>16))>>>0)/4294967295;}
function terrainHeight(x,z,seed){const broad=Math.sin((x+seed%17)*.14)*1.7+Math.cos((z-seed%13)*.13)*1.4;const hills=(hash2(Math.floor(x/5),Math.floor(z/5),seed)-.5)*2.3;return Math.max(1,Math.floor(3+broad+hills));}
test('terrain is deterministic for the same inputs',()=>{assert.equal(terrainHeight(4,-7,123),terrainHeight(4,-7,123));assert.equal(hash2(4,-7,123),hash2(4,-7,123));});
test('terrain height stays in a plausible initial range',()=>{for(let x=-28;x<28;x+=3)for(let z=-28;z<28;z+=3){const h=terrainHeight(x,z,77);assert.ok(Number.isInteger(h));assert.ok(h>=1&&h<8);}});
test('block coordinates round-trip',()=>{const key=(x,y,z)=>`${x},${y},${z}`;const parse=k=>k.split(',').map(Number);assert.deepEqual(parse(key(-12,4,27)),[-12,4,27]);});
